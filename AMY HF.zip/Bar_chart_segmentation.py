import numpy as np
import pandas as pd
import os
import importlib.util
import matplotlib.pyplot as plt

# ---- FONT SETTINGS (PRESENTATION) ----
plt.rcParams.update({
    'font.size': 20,
    'axes.titlesize': 26,
    'axes.labelsize': 22,
    'xtick.labelsize': 18,
    'ytick.labelsize': 18,
})

plt.rcParams['axes.linewidth'] = 1
plt.rcParams['xtick.major.width'] = 1
plt.rcParams['ytick.major.width'] = 1
plt.rcParams['xtick.major.size'] = 5
plt.rcParams['ytick.major.size'] = 5


# ---- PARAMETERS ----
window = 296
threshold = 16.672860308808694
min_duration = int(485)

data_folder = "FF_Trimmed_Flight_Data_for_threshold"
centroid_folder = "FF_Centroids_for_threshold"


# ---- LOAD DATA ----
def load_data_module(path):
    spec = importlib.util.spec_from_file_location("data_module", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.data


# ---- LOAD CENTROIDS ----
def load_centroids(path):
    centroids = []
    with open(path, "r") as f:
        for line in f:
            line = line.strip().replace("[", "").replace("]", "")
            parts = line.split(",")
            row = [float(p) for p in parts if p != ""]
            centroids.append(row)
    return np.array(centroids)


# ---- MEDIAN DISTANCE ----
def median_distance_per_timestep(data, centroids):
    birds = list(data.keys())
    T = len(data[birds[0]])

    med_dist = np.empty(T)

    for t in range(T):
        cx, cy, cz = centroids[t]
        dists = []

        for bird in birds:
            row = data[bird][t]
            x, y, z = row[1], row[2], row[3]
            d = np.sqrt((x - cx)**2 + (y - cy)**2 + (z - cz)**2)
            dists.append(d)

        med_dist[t] = np.nanmedian(dists)

    return med_dist


# ---- SEGMENTS ----
def extract_segments(labels):
    segments = []
    start = 0

    for i in range(1, len(labels)):
        if labels[i] != labels[i - 1]:
            segments.append((start, i))
            start = i

    segments.append((start, len(labels)))
    return segments


# ---- STORAGE ----
stable_percentages = []
erratic_percentages = []
flight_labels = []

stable_means = []
erratic_means = []

stable_times = []
erratic_times = []
total_times = []


# ---- MAIN LOOP ----
for i in range(1, 12):

    print(f"\nProcessing ff{i}...")

    data_path = os.path.join(data_folder, f"ff{i}_data.py")
    data = load_data_module(data_path)

    centroid_path = os.path.join(centroid_folder, f"centroids_{i}.txt")
    centroids = load_centroids(centroid_path)

    med_dist = median_distance_per_timestep(data, centroids)

    rolling_var = pd.Series(med_dist).rolling(window).var().to_numpy()

    valid = ~np.isnan(rolling_var)
    rolling_var = rolling_var[valid]

    labels = rolling_var > threshold
    segments = extract_segments(labels)

    stable_time = 0
    erratic_time = 0

    stable_vars = []
    erratic_vars = []

    total_time = len(rolling_var)

    for start, end in segments:
        length = end - start
        segment_var = rolling_var[start:end]
        seg_var = np.nanmean(segment_var)

        low_var = (labels[start] == False)
        long = (length >= min_duration)

        if low_var and long:
            stable_time += length
            stable_vars.append(seg_var)
        else:
            erratic_time += length
            erratic_vars.append(seg_var)

    stable_frac = stable_time / total_time
    erratic_frac = erratic_time / total_time

    stable_percentages.append(stable_frac)
    erratic_percentages.append(erratic_frac)
    flight_labels.append(f"ff{i}")

    stable_times.append(stable_time)
    erratic_times.append(erratic_time)
    total_times.append(total_time)

    stable_mean = np.nanmean(stable_vars)
    erratic_mean = np.nanmean(erratic_vars)

    stable_means.append(stable_mean)
    erratic_means.append(erratic_mean)

    print(f"ff{i}:")
    print(f"  Stable mean variance: {stable_mean:.2f}")
    print(f"  Erratic mean variance: {erratic_mean:.2f}")
    print(f"  Stable proportion: {stable_frac:.2%}")
    print(f"  Erratic proportion: {erratic_frac:.2%}")

# ---- STACKED BAR CHART (SLIDE-OPTIMISED) ----
x = np.arange(len(flight_labels))
width = 0.5

plt.figure(figsize=(16, 8))

# ---- MATCH SEGMENTATION COLOURS ----
stable_color = '#4CAF50'
erratic_color = '#E57373'

# ---- STACKED BARS ----
plt.bar(x, stable_percentages, width,
        label="Stable (Low Variance)", color=stable_color)

plt.bar(x, erratic_percentages, width,
        bottom=stable_percentages,
        label="Erratic (High Variance)", color=erratic_color)

# ---- AXES ----
plt.xlabel("Free Flight Number")
plt.ylabel("Flight Duration (%)")
plt.title("Stable vs Erratic Behaviour Across Flights")

plt.xticks(x, flight_labels)

# ---- Y AXIS ----
plt.ylim(0, 1.05)
yticks = np.linspace(0, 1, 6)
plt.yticks(yticks, [f"{int(y*100)}%" for y in yticks])

# ---- LEGEND ----
plt.legend(loc='lower right')
# ---- CLEAN GRID ----
plt.grid(axis='y', linestyle='--', alpha=0.2)

plt.tight_layout()
plt.savefig("stable_vs_erratic_flights.png", dpi=300, bbox_inches='tight')
plt.show()
