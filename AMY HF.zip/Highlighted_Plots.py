import numpy as np
import pandas as pd
import os
import importlib.util
import matplotlib.pyplot as plt

# ---- FONT SETTINGS ----
plt.rcParams.update({
    'font.size': 18,
    'axes.titlesize': 20,
    'axes.labelsize': 18,
    'xtick.labelsize': 16,
    'ytick.labelsize': 16,
    'legend.fontsize': 16
})

# ---- LINE / AXIS STYLING ----
plt.rcParams['axes.linewidth'] = 1.5
plt.rcParams['xtick.major.width'] = 1.5
plt.rcParams['ytick.major.width'] = 1.5
plt.rcParams['xtick.major.size'] = 6
plt.rcParams['ytick.major.size'] = 6

# ---- PARAMETERS ----
window = 296
threshold = 16.672860308808694
min_duration = int(485)
dt = 0.2

data_folder = "FF_Trimmed_Flight_Data_for_threshold"
centroid_folder = "FF_Centroids_for_threshold"
output_folder = "segmentation_plots"

os.makedirs(output_folder, exist_ok=True)


# ---- LOAD DATA ----
def load_data_module(path):
    spec = importlib.util.spec_from_file_location("data_module", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.data


# ---- LOAD CENTROIDS ----
def load_centroids(path):
    centroids = []
    with open(path, "r") as f:
        for line in f:
            line = line.strip().replace("[", "").replace("]", "")
            parts = line.split(",")
            row = [float(p) for p in parts if p != ""]
            centroids.append(row)
    return np.array(centroids)


# ---- AVG DISTANCE ----
def average_distance_per_timestep(data, centroids):
    birds = list(data.keys())
    T = len(data[birds[0]])
    avg_dist = np.empty(T)

    for t in range(T):
        cx, cy, cz = centroids[t]
        dists = []

        for bird in birds:
            row = data[bird][t]
            x, y, z = row[1], row[2], row[3]
            d = np.sqrt((x - cx)**2 + (y - cy)**2 + (z - cz)**2)
            dists.append(d)

        avg_dist[t] = np.nanmedian(dists)

    return avg_dist


# ---- SEGMENTS ----
def extract_segments(labels):
    segments = []
    start = 0

    for i in range(1, len(labels)):
        if labels[i] != labels[i - 1]:
            segments.append((start, i))
            start = i

    segments.append((start, len(labels)))
    return segments


# ---- PLOTTING (FULL BACKGROUND SHADING) ----
def plot_full_background(time, avg_dist, labels, segments, min_duration, title, save_path):

    plt.figure(figsize=(12, 6))  # match your other plot height

    # Create stable mask
    is_stable = np.zeros(len(time), dtype=bool)

    for start, end in segments:
        length = end - start
        low_var = (labels[start] == False)
        long = (length >= min_duration)

        if low_var and long:
            is_stable[start:end] = True

    ymin = np.min(avg_dist)
    ymax = np.max(avg_dist)

    # Background shading
    plt.fill_between(time, ymin, ymax, where=is_stable,
                     color='green', alpha=0.2, interpolate=True, label="Stable")

    plt.fill_between(time, ymin, ymax, where=~is_stable,
                     color='red', alpha=0.2, interpolate=True, label="Erratic")

    # Line (match thickness style)
    plt.plot(time, avg_dist, color='black', linewidth=2)

    plt.xlabel("Time (s)")
    plt.ylabel("Median Distance to Centroid (m)")
    plt.title(title)

    plt.legend()
    plt.tight_layout()

    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()


# ---- MAIN ----
for i in range(1,2):

    print(f"Processing ff{i}...")

    data_path = os.path.join(data_folder, f"ff{i}_data.py")
    data = load_data_module(data_path)

    centroid_path = os.path.join(centroid_folder, f"centroids_{i}.txt")
    centroids = load_centroids(centroid_path)

    avg_dist = average_distance_per_timestep(data, centroids)

    rolling_var = pd.Series(avg_dist).rolling(window).var().to_numpy()
    labels = rolling_var > threshold

    valid = ~np.isnan(rolling_var)
    labels = labels[valid]
    avg_dist = avg_dist[valid]

    time = np.arange(len(avg_dist)) * dt

    segments = extract_segments(labels)

    save_path = os.path.join(output_folder, f"new_ff{i}_segmentation.png")

    plot_full_background(
        time,
        avg_dist,
        labels,
        segments,
        min_duration,
        title=f"Median Distance to Flock Centroid with Behaviour Segmentation (Free Flight {i})",
        save_path=save_path)

print("\nAll plots saved in:", output_folder)