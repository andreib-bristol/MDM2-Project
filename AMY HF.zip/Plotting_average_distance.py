import numpy as np
import matplotlib.pyplot as plt

# ---- FONT SETTINGS ----
plt.rcParams.update({
    'font.size': 18,
    'axes.titlesize': 20,
    'axes.labelsize': 18,
    'xtick.labelsize': 16,
    'ytick.labelsize': 16,
    'legend.fontsize': 16
})

# ---- LINE / AXIS STYLING ----
plt.rcParams['axes.linewidth'] = 1.5
plt.rcParams['xtick.major.width'] = 1.5
plt.rcParams['ytick.major.width'] = 1.5
plt.rcParams['xtick.major.size'] = 6
plt.rcParams['ytick.major.size'] = 6

# ---- choose your inputs here ----
import Trimmed_Flight_Data.ff1_data   # change to ff2_data, ff3_data, etc.
CENTROIDS_TXT = "Centroids/centroids_1.txt"
DT_SECONDS = 0.2

data = Trimmed_Flight_Data.ff1_data.data
dataset_name = Trimmed_Flight_Data.ff1_data.__name__.split('.')[-1].replace('_data', '')
# ---------------------------------

def load_centroids(path):
    centroids = np.loadtxt(path, delimiter=",")
    return np.atleast_2d(centroids)

def average_distance_per_timestep(data, centroids):
    birds = list(data.keys())
    T = len(data[birds[0]])

    avg_dist = np.empty(T, dtype=float)

    for t in range(T):
        cx, cy, cz = centroids[t]

        dists = []
        for bird in birds:
            row = data[bird][t]
            x, y, z = row[1], row[2], row[3]

            d = np.sqrt((x - cx) ** 2 + (y - cy) ** 2 + (z - cz) ** 2)
            dists.append(d)

        avg_dist[t] = np.nanmedian(dists)

    return avg_dist

centroids = load_centroids(CENTROIDS_TXT)
avg_distances = average_distance_per_timestep(data, centroids)

# Build time axis
T = len(avg_distances)
time_seconds = np.arange(T) * DT_SECONDS

plt.figure(figsize=(12, 6))
plt.plot(time_seconds, avg_distances, color="black", linewidth=2)

plt.xlabel("Time (s)")
plt.ylabel("Median Distance to Centroid (m)")
plt.title("Median Distance to Flock Centroid Over Time (Free Flight 1)")

plt.tight_layout()

# ---- SAVE FIGURE ----
plt.savefig("ff1_avg_dist_plot.png", dpi=300, bbox_inches='tight')

plt.show()